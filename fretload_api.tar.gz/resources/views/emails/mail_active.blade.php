<body>
    <h3><a href="{{$link}}">Activez votre compte ICI</a></h3>
</body>
