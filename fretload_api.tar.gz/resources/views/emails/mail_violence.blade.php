<div class="">
    <div class="aHl">

    </div>
    <div id=":433" tabindex="-1">

    </div>
    <div id=":466" class="ii gt">
        <div id=":3zv" class="a3s aXjCH msg-6652382994262988212">
            <u></u>

            <div style="height:100%;margin:0;padding:0;width:100%">

                <center>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="m_-6652382994262988212bodyTable" style="border-collapse:collapse;height:100%;margin:0;padding:0;width:100%">
                        <tbody>
                            <tr>
                                <td align="center" valign="top" id="m_-6652382994262988212bodyCell" style="height:100%;margin:0;padding:0;width:100%">

                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                                        <tbody>
                                            <tr>
                                                <td align="center" valign="top" id="m_-6652382994262988212templateHeader" style="background:#f7f7f7 none no-repeat 50% 50%/cover;background-color:#f7f7f7;background-image:none;background-repeat:no-repeat;background-position:50% 50%;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">

                                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-6652382994262988212templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                                        <tbody>
                                                            <tr>
                                                                <td valign="top" class="m_-6652382994262988212headerContainer" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0;padding-bottom:0">
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td align="center" valign="top" id="m_-6652382994262988212templateBody" style="background:#aaaaaa none no-repeat 50% 50%/cover;background-color:#aaaaaa;background-image:none;background-repeat:no-repeat;background-position:50% 50%;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-6652382994262988212templateContainer" style="border-collapse:collapse;max-width:600px!important">
                                                        <tbody>
                                                            <tr>
                                                                <td valign="top" class="m_-6652382994262988212bodyContainer" style="background:#ffffff none no-repeat center/cover;background-color:#ffffff;background-image:none;background-repeat:no-repeat;background-position:center;background-size:cover;border-top:0;border-bottom:0;padding-top:0px;padding-bottom:0px">
                                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td valign="top" style="padding:9px">
                                                                                    <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" style="min-width:100%;border-collapse:collapse">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td valign="top" style="padding-right:9px;padding-left:9px;padding-top:0;padding-bottom:0;text-align:center">


                                                                                                    <img align="center" alt="" src="https://cejus.org/imgs/sos.png"
                                                                                                        width="564" style="max-width:1200px;padding-bottom:0;display:inline!important;vertical-align:bottom;border:0;height:auto;outline:none;text-decoration:none"
                                                                                                        class="m_-6652382994262988212mcnImage CToWUd a6T" tabindex="0">
                                                                                                    <div class="a6S" dir="ltr" style="opacity: 0.01; left: 535.452px; top: 169.182px;">
                                                                                                        <div id=":47o" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="Télécharger la pièce jointe " data-tooltip-class="a1V" data-tooltip="Télécharger">
                                                                                                            <div class="aSK J-J5-Ji aYr"></div>
                                                                                                        </div>
                                                                                                    </div>


                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td valign="top" style="padding-top:9px">



                                                                                    <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_-6652382994262988212mcnTextContentContainer">
                                                                                        <tbody>
                                                                                            <!-- DEBUT DE LA PARTIE VICTIME -->
                                                                                            <tr>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" colspan="2" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                                                    <div style="text-align:justify; font-size: small;">
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:center"> <strong style="color: #0081F9;">LES INFORMATIONS DE LA VICTIME</strong></p>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>

                                                                                            @if (isset($name))
                                                                                            <tr>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">

                                                                                                    <div style="text-align:justify; font-size: small;">

                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Nom et Prénom : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Email : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Age :</p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Sexe : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Ville/Quartier : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Téléphone : </p>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                                                    <div style="text-align:justify">

                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $name .' '. $first_name}}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $email }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $age }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $sexe == 'M' ? 'Homme' : 'Femme' }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $address }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $tels }}</strong></p>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>
                                                                                            @endif

                                                                                            <!-- FIN DE LA PARTIE VICTIME -->
                                                                                            @if (isset($p_name))
                                                                                            <tr>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" colspan="2" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                                                    <div style="text-align:justify; font-size: small;">
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:center"> <strong style="color: #0081F9;">LES INFORMATIONS DE LA PERSONNE NON VICTIME</strong></p>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>

                                                                                            <tr>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">

                                                                                                    <div style="text-align:justify; font-size: small;">

                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Nom et Prénom : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Email : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Age :</p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Sexe : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Ville/Quartier : </p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> Téléphone : </p>
                                                                                                    </div>
                                                                                                </td>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                                                    <div style="text-align:justify">
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $p_name .' '. $p_first_name}}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $p_email }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $p_age }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"><strong style="color: black;"> {{ $p_sexe == 'M' ? 'Homme' : 'Femme' }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $p_address }}</strong></p>
                                                                                                        <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left"> <strong style="color: black;"> {{ $p_tels }}</strong></p>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>
                                                                                            @endif

                                                                                            @if (isset($msg))
                                                                                            <tr>
                                                                                                <td valign="top" class="m_-6652382994262988212mcnTextContent" colspan="2" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">
                                                                                                    <p dir="ltr" style="margin:15px 0;padding:0;color:#F3A100;font-family:Helvetica;font-size:15px;line-height:150%;text-align:center"> <strong style="color: #0081F9;">RESUME DE LA PLAINTE</strong></p>
                                                                                                <p dir="ltr" style="margin:15px 0;padding:0;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">{{ $msg }}</p>

                                                                                                </td>
                                                                                            </tr>
                                                                                            @endif
                                                                            </tr>
                                                                            </tbody>
                                                                            </table>



                                                                            </td>
                                                            </tr>
                                                            </tbody>
                                                            </table>

                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                <tbody>
                                                                    <tr>
                                                                        <td align="center" valign="top" style="padding:9px">
                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td align="center" style="padding-left:9px;padding-right:9px">
                                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                                                <tbody>
                                                                                                    <tr>
                                                                                                        <td align="center" valign="top" style="padding-top:9px;padding-right:9px;padding-left:9px">
                                                                                                            <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
                                                                                                                <tbody>
                                                                                                                    <tr>
                                                                                                                        <td align="center" valign="top">





                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td valign="top" style="padding-right:15px;padding-bottom:9px">
                                                                                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                                                                                                                                                <tbody>
                                                                                                                                                    <tr>
                                                                                                                                                        <td align="left" valign="middle" style="padding-top:5px;padding-right:15px;padding-bottom:5px;padding-left:9px">
                                                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                                                                                                                <tbody>
                                                                                                                                                                    <tr>

                                                                                                                                                                        <td align="center" valign="middle" width="24">
                                                                                                                                                                            <a href="https://www.facebook.com/cliniquejuridiquecejus/" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://eepurl.us10.list-manage.com/track/click?u%3Db3941aaa02376471c9b9b7a99%26id%3D53823162e3%26e%3D69144b586b&amp;source=gmail&amp;ust=1593713266477000&amp;usg=AFQjCNF_Dz2Mg-djhO-N6mekXN5rxyL-qw"><img src="https://ci5.googleusercontent.com/proxy/KLWDyxU_2JT5nOGTE6_NSp-hT37kpCU8B8HLih6GyBnhKJEvCDQsIeq4uLfJ7CQWsSCfpfcbCXVh74IrAuFYiXcU4R2sPN1CInMYwE7DpPIiYM9dGmBbl7FrtmeFZ6I=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-facebook-48.png"
                                                                                                                                                                                    alt="Facebook" style="display:block;border:0;height:auto;outline:none;text-decoration:none"
                                                                                                                                                                                    height="24" width="24" class="CToWUd"></a>
                                                                                                                                                                        </td>


                                                                                                                                                                    </tr>
                                                                                                                                                                </tbody>
                                                                                                                                                            </table>
                                                                                                                                                        </td>
                                                                                                                                                    </tr>
                                                                                                                                                </tbody>
                                                                                                                                            </table>
                                                                                                                                        </td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>













                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td valign="top" style="padding-right:15px;padding-bottom:9px">
                                                                                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                                                                                                                                                <tbody>
                                                                                                                                                    <tr>
                                                                                                                                                        <td align="left" valign="middle" style="padding-top:5px;padding-right:15px;padding-bottom:5px;padding-left:9px">
                                                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                                                                                                                <tbody>
                                                                                                                                                                    <tr>

                                                                                                                                                                        <td align="center" valign="middle" width="24">
                                                                                                                                                                            <a href="https://www.youtube.com/channel/UC1cx8ObOL8wi6tom11ERymg" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://eepurl.us10.list-manage.com/track/click?u%3Db3941aaa02376471c9b9b7a99%26id%3D0df99de268%26e%3D69144b586b&amp;source=gmail&amp;ust=1593713266477000&amp;usg=AFQjCNH3MddwZ4ZGDm8USAR6XjGY6QlCVA"><img src="https://ci3.googleusercontent.com/proxy/UZmsqbR0YicV2Dut8L3zgzEo4jupJEoo_M2eyGVoTUqJ8TC_2hipkr2l-JV-uTKoVQAGjTEuVd_3mFGuOKWqoj2ji0OjjHB1ShyYPzqUidP9s75s194CW40mMOmhPw=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-youtube-48.png"
                                                                                                                                                                                    alt="YouTube" style="display:block;border:0;height:auto;outline:none;text-decoration:none"
                                                                                                                                                                                    height="24" width="24" class="CToWUd"></a>
                                                                                                                                                                        </td>


                                                                                                                                                                    </tr>
                                                                                                                                                                </tbody>
                                                                                                                                                            </table>
                                                                                                                                                        </td>
                                                                                                                                                    </tr>
                                                                                                                                                </tbody>
                                                                                                                                            </table>
                                                                                                                                        </td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>






                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="display:inline;border-collapse:collapse">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td valign="top" style="padding-right:0;padding-bottom:9px">
                                                                                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-collapse:collapse">
                                                                                                                                                <tbody>
                                                                                                                                                    <tr>
                                                                                                                                                        <td align="left" valign="middle" style="padding-top:5px;padding-right:10px;padding-bottom:5px;padding-left:9px">
                                                                                                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" width="" style="border-collapse:collapse">
                                                                                                                                                                <tbody>
                                                                                                                                                                    <tr>

                                                                                                                                                                        <td align="center" valign="middle" width="24">
                                                                                                                                                                            <a href="https://www.linkedin.com/in/dieudonn%C3%A9-kossi-160b0a13a" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://eepurl.us10.list-manage.com/track/click?u%3Db3941aaa02376471c9b9b7a99%26id%3D8cc338c224%26e%3D69144b586b&amp;source=gmail&amp;ust=1593713266477000&amp;usg=AFQjCNGjt6tViVLdnJSlnppvvWJfZ9p-Kg"><img src="https://ci5.googleusercontent.com/proxy/FR4I0VM10pxcUwbQ63iIF6cAOqyzEbM1yC4ru84XQ1cT1RbvvmtJzUt4RdH1WUB452ecisGFRwh877ppJp5BhUmQhUWIABs5JUY80JFlBF08huivKdmS6R-dPg=s0-d-e1-ft#https://cdn-images.mailchimp.com/icons/social-block-v2/color-link-48.png"
                                                                                                                                                                                    alt="Website" style="display:block;border:0;height:auto;outline:none;text-decoration:none"
                                                                                                                                                                                    height="24" width="24" class="CToWUd"></a>
                                                                                                                                                                        </td>


                                                                                                                                                                    </tr>
                                                                                                                                                                </tbody>
                                                                                                                                                            </table>
                                                                                                                                                        </td>
                                                                                                                                                    </tr>
                                                                                                                                                </tbody>
                                                                                                                                            </table>
                                                                                                                                        </td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>




                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                </tbody>
                                                                                                            </table>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                </tbody>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" class="m_-6652382994262988212mcnDividerBlock" style="min-width:100%;border-collapse:collapse;table-layout:fixed!important">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="min-width:100%;padding:18px">
                                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                                <tbody>
                                                                                    <tr>
                                                                                        <td>
                                                                                            <span></span>
                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>

                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="min-width:100%;border-collapse:collapse">
                                                                <tbody>
                                                                    <tr>
                                                                        <td valign="top" style="padding-top:9px">



                                                                            <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%;min-width:100%;border-collapse:collapse" width="100%" class="m_-6652382994262988212mcnTextContentContainer">
                                                                                <tbody>
                                                                                    <tr>

                                                                                        <td valign="top" class="m_-6652382994262988212mcnTextContent" style="padding-top:0;padding-right:18px;padding-bottom:9px;padding-left:18px;word-break:break-word;color:#757575;font-family:Helvetica;font-size:16px;line-height:150%;text-align:left">


                                                                                        </td>
                                                                                    </tr>
                                                                                </tbody>
                                                                            </table>



                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                            </td>
                                            </tr>
                                            </tbody>
                                            </table>

                                            </td>
                            </tr>

                            </tbody>
                            </table>

                            </td>
                            </tr>
                        </tbody>
                    </table>
                </center>
                <img src="https://ci5.googleusercontent.com/proxy/wqbN484KLY9Nkj2DMdtlHUACPPeGYrBqGRS3tMgW8p-jWP25Am_wGX8OOVVXCCc3_g_NWR83nh0AZrLXJ5tBMOdgPxrj9CnPIRedgsr2wq2EZ8p3KZ52U9QhapP2gghfIvI7H8mn_iU8-UxydEsK4n_MWMMOcY3wheYjIw=s0-d-e1-ft#https://eepurl.us10.list-manage.com/track/open.php?u=b3941aaa02376471c9b9b7a99&amp;id=12f4b9569f&amp;e=69144b586b"
                    height="1" width="1" class="CToWUd"></div>
            <div class="yj6qo"></div>
            <div class="adL">
            </div>
        </div>
    </div>
    <div id=":438" class="ii gt" style="display:none">
        <div id=":437" class="a3s aXjCH undefined"></div>
    </div>
    <div class="hi"></div>
</div>
