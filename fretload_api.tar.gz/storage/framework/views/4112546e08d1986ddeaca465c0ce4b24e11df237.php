<body>
    <h3><a href="<?php echo e($link); ?>">Activez votre compte ICI</a></h3>
</body>
<?php /**PATH /home/infini/base/akue/demo/test_api/resources/views/emails/mail_active.blade.php ENDPATH**/ ?>